﻿using Application.Common;
using Data;
using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services.Persons
{
    public class PersonService : IPersonService
    {
        private readonly LibraryContext _context;

        public PersonService(LibraryContext context)
        {
            _context = context;
        }

        public async Task<Result<List<Person>>> GetPersonsAsync()
        {
            var persons = await _context.Persons.ToListAsync();
            return Result<List<Person>>.Success(persons);
        }
    }
}
