﻿using Microsoft.AspNetCore.Mvc;

namespace WebApi.Controllers
{
    public class PersonsController : BaseApiController
    {
        [ApiController]
        [Route("api/persons")]

        [HttpGet]
        public async Task<IActionResult> GetBooks()
        {
            var response = await _bookService.GetBooksAsync();

            if (!response.IsSuccess)
            {
                return response.ToActionResult(this);
            }

            var books = response.Value!;

            var bookDtos = books
                .Select(b => b.ToDto())
                .ToList();

            return Ok(bookDtos);
        }
    }
}
