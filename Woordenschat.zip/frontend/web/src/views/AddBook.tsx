export default function AddBook() {
  return (
    <div>
      <h1>Boek Toevoegen</h1>
    </div>
  );
}
